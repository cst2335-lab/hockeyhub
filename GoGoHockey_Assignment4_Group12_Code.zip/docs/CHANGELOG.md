# GoGoHockey 网站优化修改日志

> **文档索引（2026-05）**：当前待办见 [TASKS.md](./TASKS.md)；架构见 [ARCHITECTURE.md](./ARCHITECTURE.md)。下文为历史记录，链接中的旧文件名可能已更名。

本文档详细记录截至目前的修改完善工作。

---

## 一、冰场预订链接 Locale 修复

**日期**：2025-02  
**优先级**：高  
**文件**：`app/[locale]/(dashboard)/rinks/page.tsx`

### 修改内容
- 添加 `usePathname` 获取当前 locale
- 新增 `withLocale` 辅助函数
- 将 "Book Now" 链接从 `href={/book/${r.id}}` 改为 `href={withLocale(\`/book/${r.id}\`)}`

### 解决的问题
- 从法语路由（如 `/fr/rinks`）点击预订会错误跳转到 `/book/xxx`，丢失 locale
- 修复后保持语言上下文正确

---

## 二、Toast 替代 alert

**日期**：2025-02  
**优先级**：高  
**文件**：
- `app/[locale]/layout.tsx` - 添加 Sonner `<Toaster />`
- `app/[locale]/(dashboard)/book/[rinkId]/page.tsx`
- `app/[locale]/(dashboard)/my-games/page.tsx`
- `app/[locale]/(dashboard)/manage-rink/page.tsx`
- `app/[locale]/(dashboard)/games/new/page.tsx`
- `app/[locale]/(dashboard)/games/[id]/page.tsx`
- `app/[locale]/(dashboard)/games/[id]/edit/page.tsx`
- `app/[locale]/(dashboard)/bookings/[id]/page.tsx`

### 修改内容
- 引入 `toast` from `sonner`
- 将 `alert()` 替换为 `toast.success()` / `toast.error()` / `toast.info()`
- 在根布局中添加 `<Toaster position="top-center" richColors closeButton />`

### 解决的问题
- 原生 `alert()` 会阻塞界面
- Toast 提供非侵入式、可关闭的提示体验

---

## 三、预订结束时间计算修复

**日期**：2025-02  
**优先级**：高  
**文件**：`app/[locale]/(dashboard)/book/[rinkId]/page.tsx`

### 修改内容
- 使用 `date-fns` 的 `parse`、`addHours`、`format` 替代手动计算
- `calcEndTime` 返回 `{ endTime, endDate, isOvernight }`
- 增加跨夜校验：若 `isOvernight` 为 true，提示 "Bookings cannot span midnight..." 并阻止提交

### 解决的问题
- 原逻辑 `(h + durHours) % 24` 在跨夜时产生错误（如 22:00 + 3h → 01:00 次日，但 `booking_date` 未变）
- 现逻辑正确计算结束时间，并禁止跨夜预订

---

## 四、冰场可用时段校验

**日期**：2025-02  
**优先级**：高  
**文件**：`app/[locale]/(dashboard)/book/[rinkId]/page.tsx`

### 修改内容
- 新增状态：`existingBookings`、`loadingSlots`
- 新增 `fetchExistingBookings`：按 rinkId + bookingDate 查询非 cancelled 预订
- 新增 `hasSlotConflict`：判断请求时段与已有预订是否重叠
- 选择日期后自动加载该日期的已有预订
- 时段下拉框中：已占用时段显示 "(booked)" 并禁用
- 提交前再次校验冲突，冲突时 toast 提示并阻止提交

### 解决的问题
- 原无冲突检查，可能造成同一冰场同一时段重复预订
- 现支持前端冲突检测与提交前二次校验

---

## 五、i18n 全面应用

**日期**：2025-02  
**优先级**：高  
**文件**：
- `messages/en.json`、`messages/fr.json` - 扩展翻译 key
- `components/layout/footer.tsx`
- `components/layout/navbar.tsx`
- `app/[locale]/(dashboard)/rinks/page.tsx`
- `app/[locale]/(dashboard)/book/[rinkId]/page.tsx`
- `app/[locale]/(dashboard)/dashboard/page.tsx`

### 修改内容

#### 5.1 翻译文件扩展
- `nav`：privacy, terms, contact
- `actions`：bookNow, confirmBooking
- `footer`：poweredBy
- `rinks`：title, available, searchPlaceholder, allPrices, budget, standard, premium, sortByName, sortByPrice, allCities, clearFilters, noMatch, quickStats, totalRinks, avgPrice, lowestPrice, highestPrice, bandBudget, bandStandard, bandPremium
- `book`：title, rinkDetails, bookingInfo, date, startTime, duration, selectTime, hour, hours, priceSummary, iceTime, platformFee, total, creating, checkingAvailability, booked, slotsBookedHint
- `dashboard`：title, openGames, upcomingBookings, totalRinks

#### 5.2 组件更新
- Footer：Powered by Vercel、Privacy、Terms、Contact 使用翻译
- Navbar：Games、Clubs、Rinks、Notifications、Post Game、Profile、Logout、Login、Sign Up 使用翻译
- Rinks 页：标题、筛选、排序、统计等使用翻译
- Book 页：表单标签、价格摘要、按钮文案使用翻译
- Dashboard：标题与指标标签使用翻译

### 解决的问题
- 大量硬编码英文，不利于多语言
- 现支持英语/法语切换

---

## 六、Footer 真实链接

**日期**：2025-02  
**优先级**：高  
**文件**：
- 新建 `app/[locale]/privacy/page.tsx` - 隐私政策页
- 新建 `app/[locale]/terms/page.tsx` - 服务条款页
- 新建 `app/[locale]/contact/page.tsx` - 联系页
- `components/layout/footer.tsx`

### 修改内容
- 新建 Privacy Policy、Terms of Service、Contact 三页
- Footer 使用 `usePathname` 获取 locale，将 Privacy/Terms/Contact 链接到对应页面
- 链接格式：`/privacy`、`/terms`、`/contact`，并通过 `withLocale` 保持多语言

### 解决的问题
- 原链接为 `href="#"`，无实际内容
- 现提供可访问的隐私、条款、联系页面

---

## 七、通知未读数徽章

**日期**：2025-02  
**优先级**：中  
**文件**：`components/layout/navbar.tsx`

### 修改内容
- 新增状态 `unreadCount`
- 新增 `loadUnreadCount`（`useCallback`）从 `notifications` 表统计未读数
- 在 `useEffect` 中：用户登录后加载未读数，并订阅 Supabase `postgres_changes` 实时更新
- 在通知铃铛旁显示红色数字徽章：`unreadCount > 0` 时显示，>99 显示 "99+"
- 为 Link 添加 `aria-label` 提升可访问性

### 解决的问题
- 原无未读数提示
- 现可在 Navbar 直接看到未读通知数量

---

## 八、Bug 修复：useCallback 未导入

**日期**：2025-02  
**文件**：`components/layout/navbar.tsx`

### 修改内容
- 在 React 导入中加入 `useCallback`

### 解决的问题
- 运行时错误：`useCallback is not defined`
- 因使用 `useCallback` 但未导入导致

---

## 修改文件汇总

| 类型 | 文件路径 |
|------|----------|
| 新建 | `app/[locale]/privacy/page.tsx` |
| 新建 | `app/[locale]/terms/page.tsx` |
| 新建 | `app/[locale]/contact/page.tsx` |
| 修改 | `app/[locale]/layout.tsx` |
| 修改 | `app/[locale]/(dashboard)/book/[rinkId]/page.tsx` |
| 修改 | `app/[locale]/(dashboard)/rinks/page.tsx` |
| 修改 | `app/[locale]/(dashboard)/dashboard/page.tsx` |
| 修改 | `app/[locale]/(dashboard)/my-games/page.tsx` |
| 修改 | `app/[locale]/(dashboard)/manage-rink/page.tsx` |
| 修改 | `app/[locale]/(dashboard)/games/new/page.tsx` |
| 修改 | `app/[locale]/(dashboard)/games/[id]/page.tsx` |
| 修改 | `app/[locale]/(dashboard)/games/[id]/edit/page.tsx` |
| 修改 | `app/[locale]/(dashboard)/bookings/[id]/page.tsx` |
| 修改 | `components/layout/navbar.tsx` |
| 修改 | `components/layout/footer.tsx` |
| 修改 | `messages/en.json` |
| 修改 | `messages/fr.json` |

---

## 技术栈与依赖

- **框架**：Next.js 15.5.12
- **国际化**：next-intl
- **Toast**：sonner
- **日期处理**：date-fns
- **数据库**：Supabase

---

## 九、P0 修改方案实施（2026-02）

**日期**：2026-02  
**分支**：feature/ui-and-improvements-2026-02-12

### 9.1 统一加载状态
- **新建**：`components/ui/skeleton.tsx`（Skeleton、DashboardSkeleton、CardListSkeleton、FormSkeleton）
- **新建**：`app/[locale]/(dashboard)/loading.tsx`（Dashboard 骨架屏）
- **新建**：`app/[locale]/loading.tsx`（Locale 级 LoadingSpinner）

### 9.2 错误边界
- **新建**：`app/[locale]/error.tsx`（统一错误页，提供「重试」「返回首页」）
- **新建**：`components/error-boundary.tsx`（可复用 ErrorBoundary 组件）

### 9.3 API 路由验证
- **新建**：`lib/api/auth.ts`（`requireAuth()` 辅助函数）
- **修改**：`app/api/notifications/test/route.ts` 使用 requireAuth 替代手动 token 解析

### 9.4 RLS 策略文档
- **新建**：`docs/SUPABASE_RLS.sql`（game_invitations、game_interests、bookings、notifications、profiles、rinks 的 RLS 策略，需在 Supabase SQL Editor 中执行）

---

## 十、P1 修改方案实施（2026-02）

**日期**：2026-02  
**分支**：feature/ui-and-improvements-2026-02-12

### 10.1 i18n 扩展
- **修改**：`messages/en.json`、`messages/fr.json`
- 新增 `games`：gamesFound、filtered、postGame、searchPlaceholder、dateFilterAll/Upcoming/Past、sortByDate/Interest/Views、clearFilters、spotsLeft、full、interested、views
- 新增 `clubs`：title、noClubs、beFirst、registerClub
- 新增 `bookings`：title、noBookings
- 新增 `notifications`：title、noNotifications、markAllRead、unreadCount

### 10.2 UI 视觉规范落地
- **修改**：`components/features/hero-section.tsx` — 渐变改为 gogo 色彩（gogo-dark → gogo-primary → gogo-secondary），主按钮白底深蓝字，次要按钮 outline + gogo-secondary
- **修改**：`components/features/game-card-working.tsx` — 顶部条、图标、徽章、按钮使用 gogo 色，卡片 hover 边框
- **修改**：`components/layout/footer.tsx` — 链接 hover 使用 gogo-primary
- **修改**：`app/[locale]/(dashboard)/rinks/page.tsx` — 卡片 hover 边框，Book Now 按钮 gogo-primary
- **修改**：`app/[locale]/(dashboard)/games/page.tsx` — 按钮、筛选器、焦点环使用 gogo 色
- **修改**：`app/globals.css` — 选中文本样式使用 gogo-secondary

### 10.3 React Query 迁移
- **新建**：`app/providers/query-provider.tsx`（QueryClientProvider）
- **修改**：`app/[locale]/layout.tsx` — 包裹 QueryProvider
- **修改**：`app/[locale]/(dashboard)/games/page.tsx` — 使用 useQuery 替代 useEffect + fetchGames
- **修改**：`app/[locale]/(dashboard)/rinks/page.tsx` — 使用 useQuery 替代 useEffect + fetchRinks

### 10.4 预订确认邮件
- **新建**：`app/api/bookings/send-confirmation/route.ts` — 使用 Resend 发送确认邮件（需 RESEND_API_KEY）
- **修改**：`app/[locale]/(dashboard)/book/[rinkId]/page.tsx` — 预订成功后调用 API 发送邮件（fire-and-forget）

---

## 十一、P2 修改方案实施（2026-02）

**日期**：2026-02

### 11.1 通用 Hooks
- **新建**：`lib/hooks/useAuth.ts` — 客户端认证状态（user、loading、signOut），订阅 onAuthStateChange
- **新建**：`lib/hooks/useDebounce.ts` — useDebounce(value, delay)、useDebouncedCallback(callback, delay)
- **新建**：`lib/hooks/index.ts` — 统一导出

### 11.2 日期格式化（locale 感知）
- **修改**：`lib/utils/format.ts`
- 新增 `formatDateByLocale(input, localeCode)`、`formatDateTimeByLocale(input, localeCode)`，使用 date-fns + enUS/fr locale
- `formatCurrency` 支持传入 locale 参数

### 11.3 SEO
- **修改**：`app/[locale]/layout.tsx` — generateMetadata：按 locale 生成 title、description、openGraph，themeColor 改为 gogo-dark
- **新建**：`app/sitemap.ts` — 为 en/fr 及静态路径生成 sitemap（baseUrl 取自 NEXT_PUBLIC_APP_URL 或 VERCEL_URL）
- **新建**：`app/robots.ts` — allow /，disallow /api/ 及测试页，sitemap 链接

### 11.4 表单优化
- **新建**：`lib/validations/game.ts` — createGameSchema（zod）：title、game_date、game_time、location、age_group、skill_level、description、max_players、contact_info
- **修改**：`app/[locale]/(dashboard)/games/new/page.tsx` — 提交前 zod 校验，字段级错误展示（fieldErrors），防重复提交（disabled + loading），按钮/输入框使用 gogo 色与 focus 环

### 11.5 图片优化
- **修改**：`next.config.mjs` — images.remotePatterns 添加 `**.supabase.co/storage/v1/object/public/**`，支持 Supabase 存储图片
- **新建**：`components/ui/optimized-image.tsx` — 封装 next/image，lazy 加载、quality 85，便于后续头像/冰场照片使用

### 11.6 预订表单 + 登录/注册 gogo 色
- **新建**：`lib/validations/booking.ts` — bookingFormSchema（bookingDate、startTime、hours 1–12）
- **修改**：`app/[locale]/(dashboard)/book/[rinkId]/page.tsx` — 提交前 zod 校验，表单/按钮 gogo 色
- **修改**：`app/[locale]/(auth)/login/LoginClient.tsx` — 按钮、链接、focus 环 gogo 色
- **修改**：`app/[locale]/(auth)/register/RegisterClient.tsx` — 按钮、链接、focus 环 gogo 色

### 11.7 useBookings / useNotifications Hooks
- **新建**：`lib/hooks/useBookings.ts` — useQuery 获取当前用户预订列表，依赖 useAuth
- **新建**：`lib/hooks/useNotifications.ts` — useQuery 获取通知列表，useMutation 支持 markAsRead、markAllAsRead、deleteNotification，realtime 订阅自动 invalidate
- **修改**：`lib/hooks/index.ts` — 导出 useBookings、useNotifications
- **修改**：`app/[locale]/(dashboard)/bookings/page.tsx` — 使用 useBookings，formatDateByLocale，i18n
- **修改**：`app/[locale]/(dashboard)/notifications/page.tsx` — 使用 useNotifications，formatDateTimeByLocale，i18n，gogo 色

### 11.8 全局 blue → gogo 色统一
- **Dashboard**：加载 spinner、统计卡片 border 与数字 gogo 色
- **Rinks**：加载 spinner、Quick Stats 区域 bg/text gogo 色
- **Games**：new/edit/[id] 表单 focus 环、Tips 框、按钮、status badge gogo 色
- **My-games**：spinner、tabs、按钮、matched 徽章、提示框 gogo 色
- **Manage-rink / Bookings**：spinner、按钮、详情数字 gogo 色
- **Clubs**：spinner、按钮、链接、verified 徽章 gogo 色
- **Navbar**：CTA 按钮渐变、底部装饰条 gogo 色
- **Layout**：侧边栏激活态 text-gogo-primary bg-gogo-secondary/10
- **Error / ErrorBoundary**：重试按钮 gogo-primary
- **Terms / Privacy / Contact**：返回链接 gogo 色
- **Notifications**：状态徽章 gogo 色
- **Profile / Profile Edit**：spinner、封面渐变、按钮、链接、徽章、focus 环 gogo 色
- **Games-test**：spinner、按钮 gogo 色

### 11.13 My-games 迁移 useQuery + withLocale
- **修改**：`app/[locale]/(dashboard)/my-games/page.tsx` — 使用 useQuery 替代 useEffect，useAuth 获取 user，queryClient.invalidateQueries 刷新数据，usePathname + withLocale 修复所有 Link 与 router.push('/login')

### 11.12 Clubs 迁移 useQuery + i18n
- **修改**：`app/[locale]/(dashboard)/clubs/page.tsx` — 使用 useQuery 替代 useEffect，移除重复 nav（使用 dashboard layout），Link + withLocale 保持 locale，i18n 全文案，Verified 徽章 gogo 色，isError 错误态
- **修改**：`messages/en.json`、`messages/fr.json` — clubs 新增 verified、visitWebsite、loadError

### 11.11 Dashboard useQuery + 无障碍
- **修改**：`app/[locale]/(dashboard)/dashboard/page.tsx` — 使用 useQuery 替代 useEffect，Promise.all 并行请求，isError 错误态，loadError i18n
- **修改**：`app/[locale]/(dashboard)/layout.tsx` — Notifications 链接、Logout 按钮添加 aria-label、focus-visible 焦点环
- **修改**：`messages/en.json`、`messages/fr.json` — dashboard 新增 loadError

### 11.10 权限：Manage Rink 仅对 rink_manager 可见 + 输入清理
- **修改**：`app/[locale]/(dashboard)/layout.tsx` — 查询 rink_managers 判断 isRinkManager，Manage Rink 链接仅对 verified rink_manager 显示；侧边栏导航改用 i18n（nav.dashboard、nav.myGames 等）
- **修改**：`messages/en.json`、`messages/fr.json` — nav 新增 manageRink、myGames、myBookings
- **新建**：`lib/utils/sanitize.ts` — sanitizePlainText 去除控制字符、限制长度，供富文本场景预留

### 11.9 Games / Rinks 列表分页
- **修改**：`app/[locale]/(dashboard)/games/page.tsx` — PAGE_SIZE=20，分页控件（Previous/Next、Page X of Y），筛选变化时重置页码
- **修改**：`app/[locale]/(dashboard)/rinks/page.tsx` — 同上分页逻辑
- **修改**：`messages/en.json`、`messages/fr.json` — games/rinks 新增 prevPage、nextPage、pageOf

---

## 十二、任务完成状态（2026-02）

### 已完成
- **P0**：加载状态、错误边界、RLS 文档、API 验证（requireAuth）
- **P1**：i18n、UI 规范落地、React Query（games/rinks/dashboard/clubs/my-games/bookings/notifications）、预订确认邮件
- **P2**：Hooks、日期格式化、SEO、表单 zod 校验、图片优化、全局 gogo 色、分页、Manage Rink 权限、sanitize 工具
- **P3**：Dashboard/Clubs/My-games useQuery、无障碍（aria-label、focus-visible）

### 11.14 测试基础设施
- **新建**：`vitest.config.ts` — node 环境，vite-tsconfig-paths 支持 @/ 路径
- **新建**：`__tests__/lib/utils/format.test.ts` — formatCurrency、formatDateByLocale、formatDateTimeByLocale
- **新建**：`__tests__/lib/utils/sanitize.test.ts` — sanitizePlainText
- **新建**：`__tests__/lib/validations/booking.test.ts` — bookingFormSchema
- **修改**：`package.json` — 新增 test、test:watch 脚本，devDependencies 添加 vitest、vite-tsconfig-paths

### 未完成（历史快照 · 2026-02）

> **2026-04 说明**：下列条目在后续迭代中已大量推进；**当前「未完成 / 进行中」的唯一权威**为 [TASKS.md](./TASKS.md) **§三、§四**（全库文档已对齐，见 §二十一）。请勿仅依据本小节判断待办。

- ~~**支付流程**~~：Stripe Checkout + Webhook 已接入（见第九至十一章、V2 P0）；需配置 Stripe 与 Webhook 密钥
- **测试**：`npm run test`（Vitest，14 用例）
- **监控**：Sentry（已集成，需 `NEXT_PUBLIC_SENTRY_DSN`）、Analytics 等按需
- **文档**：`docs/API.md`、`docs/DEPLOYMENT.md` 等已建；持续维护
- **工程收尾**：V2 P2（XSS、SEO JSON-LD 全量复核）、E2E 等见 NEXT_PHASE_TASKS

---

## 十三、阶段二导航与 RLS 补充（2026-02）

**日期**：2026-02  
**分支**：feat/nav-dashboard-and-cta  
**参考**：docs/NEXT_PHASE_TASKS.md

### 13.1 阶段二：导航与功能按钮
- 公网 Navbar 已登录时增加 Dashboard 链接（含移动端）；主页通知改为仅铃铛图标 + 未读角标
- Hero 按登录状态切换 CTA：已登录主 CTA「Go to Dashboard」，次 CTA「Find Games」；未登录保持原双按钮；新增 hero 文案（en/fr）
- 登录成功跳转由 `/games` 改为 `/dashboard`
- Footer 已登录时增加 Dashboard 链接
- clubs/new 全部使用 withLocale，移除重复顶栏，改为「Back to Clubs」；Bookings 空状态增加「Browse rinks to book」→ /rinks
- Dashboard 顶栏与主页视觉统一：bg-[#18304B]、Logo 组件、相同链接样式、LocaleSwitcher、通知仅铃铛、底部渐变条

### 13.2 RLS 补充（消除 UNRESTRICTED）
- **payments**：启用 RLS，策略「Users can view own payments」（auth.uid() = user_id）；若表结构不同需调整 docs/SUPABASE_RLS.sql
- **rink_updates_log**：启用 RLS，已登录可读、仅可插入 updated_by = auth.uid() 的记录；sync 接口用 service role 写入

### 13.3 涉及文件（阶段二）
- components/layout/navbar.tsx、footer.tsx
- components/features/hero-section.tsx
- app/[locale]/(auth)/login/LoginClient.tsx
- app/[locale]/(dashboard)/layout.tsx、clubs/new/page.tsx、bookings/page.tsx
- messages/en.json、messages/fr.json（hero、bookings.browseRinksToBook）

---

## 十四、导航与视觉优化（2026-02）

**日期**：2026-02  
**分支**：chore/next-phase-ops-and-polish

### 14.1 导航栏优化
- **移除 Post Game 按钮**：公网 Navbar 中去掉「Post Game」入口，简化导航。
- **白天/黑夜视觉模式**：全站支持 light/dark 模式切换；集成 `next-themes`；新增 `ThemeProvider`、`ThemeToggle` 组件；Navbar 增加主题切换按钮。
- **Navbar 适配主题**：白天模式白底深色文字，黑夜模式深蓝底浅色文字；链接、按钮、用户菜单、LocaleSwitcher 均适配双主题。

### 14.2 Hero 区域
- **移除波浪形白色过渡**：Hero 底部波浪形 SVG 白色过渡已删除，视觉更简洁。

### 14.3 涉及文件
- `components/layout/navbar.tsx` — 移除 Post Game、添加 ThemeToggle、双主题样式
- `components/features/hero-section.tsx` — 移除底部波浪
- `app/providers/theme-provider.tsx` — 新建
- `components/ui/theme-toggle.tsx` — 新建
- `components/ui/logo.tsx` — Logo 文字支持 dark 模式
- `components/LocaleSwitcher.tsx` — 双主题样式
- `app/[locale]/layout.tsx` — 包裹 ThemeProvider

---

## 十五、Figma 对齐与 UI 优化（2026-02）

**日期**：2026-02  
**分支**：chore/next-phase-ops-and-polish

### 15.1 导航栏优化（公网 + 登录后）
- **公网 Navbar**：主导航收进单一「Menu ▼」下拉（Games、Clubs、Rinks、About），顶栏为 Logo | Menu ▼ | 搜索 | 主题 | 语言 | 铃铛 | 用户；深蓝顶栏 + 白字（Figma 风格）；Logo 使用亮色变体；搜索框、按钮、链接白字；移动端下拉区同深蓝白字。
- **Dashboard 导航栏**：同风格深蓝顶栏 + 白字；主导航收进「Menu ▼」下拉；h-14 紧凑高度；冰场管理员可见 Manage Rink。
- **i18n**：`nav.menu` 新增（en/fr）。

### 15.2 去除全站磨砂/玻璃感
- **globals.css**：`.glass` / `.glass-dark` 改为纯色卡片（bg-card、border-border），移除 backdrop-blur 和半透明。
- **Hero**：搜索栏、CTA 按钮改为实色（bg-white），无 backdrop-blur。
- **首页**：`HomePlatformSection` 背景实色；`HomeCTASection` 按钮 hover 实色。
- **Footer、Contact**：半透明背景改为纯色（bg-muted、dark:bg-slate-900 等）。
- **Dashboard 布局、Navbar**：侧栏激活态改为实色；搜索输入框实色。
- **各页内容块**：games/[id]、profile、rinks、manage-rink、bookings 等处的 `bg-muted/50` 等改为纯色。

### 15.3 Logo 重新设计
- **图标**：由「GG」改为「GO」（呼应 Go**Go**Hockey）；使用品牌色渐变（gogo-primary → gogo-secondary）；SVG 图标，白字加粗。
- **文件**：`components/ui/logo.tsx`、`public/icon.svg`。

### 15.4 预订页 calcEndTime 修复
- **文件**：`app/[locale]/(dashboard)/book/[rinkId]/page.tsx`
- **问题**：`bookingDate` 为空时 `parse` 返回 Invalid Date，`format` 抛出 "Invalid time value" RangeError。
- **修复**：空日期时使用当天；`isValid(start)` 校验，解析失败时返回安全默认值。

### 15.5 Dashboard Bento 布局
- **参考**：Tailwind bento 示例。
- **结构**：顶部 hero（heroSubtitle、heroTitle、heroDesc）+ 指标摘要（openGames、upcomingBookings、totalRinks）+ bento 网格。
- **Bento 卡片**：Find Games（3 列）、My Bookings（3 列）；My Games、Rinks、Clubs（各 2 列）；冰场管理员时第三行 Manage Rink 全宽卡片。
- **卡片**：渐变背景 + Lucide 图标；副标题、主标题、描述；整卡为 Link；圆角贴合（rounded-tl/tr/bl/br-3xl）。
- **i18n**：`dashboard` 新增 heroSubtitle、heroTitle、heroDesc、cardGamesSub/Title/Desc 等（en/fr）。

### 15.6 涉及文件
- `components/layout/navbar.tsx` — Menu 下拉、深蓝白字
- `app/[locale]/(dashboard)/layout.tsx` — 同上
- `app/globals.css` — 纯色 glass
- `components/features/hero-section.tsx`、`home-platform-section.tsx`、`home-cta-section.tsx` — 去磨砂
- `components/layout/footer.tsx` — 纯色
- `components/ui/logo.tsx`、`public/icon.svg` — Logo
- `app/[locale]/(dashboard)/book/[rinkId]/page.tsx` — calcEndTime 修复
- `app/[locale]/(dashboard)/dashboard/page.tsx` — Bento 布局
- `messages/en.json`、`messages/fr.json` — nav.menu、dashboard 卡片文案

---

## 十六、V2 评审任务记录与文档整理

**日期**：2026-02  
**优先级**：中（文档维护）

### 修改内容

1. **新建** `docs/V2_REVIEW_NEXT_PHASE.md`：V2 三方分析综合评审结论，P0（DB 约束、Webhook 幂等、调试路由保护、RBAC 确认）、P1（HydrationBoundary、图片三层策略、Cron 安全、数据可信度、预订规则 UI 化）、P2（XSS、SEO、Zod 兜底）。
2. **更新** `docs/NEXT_PHASE_TASKS.md`：下阶段以 V2 评审优先；§四 替换为 P0/P1/P2 任务；分支建议 `feat/v2-p0-safety`、`feat/v2-p1-roi`。
3. **更新** `docs/★★★README.md`（原 `docs/README.md`）：增加 V2_REVIEW_NEXT_PHASE 索引，精简文档说明。
4. **删除** `docs/UI_OPTIMIZATION_AUDIT.md`：已完成项，内容已汇总至 CHANGELOG。
5. **删除** `docs/PHASE2_NAV_AND_BUTTON_TASKS.md`：阶段二已完成，内容已汇总至 NEXT_PHASE_TASKS §2.2。
6. **修正引用**：NEXT_PHASE_TASKS、PROJECT_REVIEW_REPORT、CHANGELOG_IMPROVEMENTS、MODIFICATION_PLAN 中指向已删除文档的链接。

### 解决的问题

- 下阶段任务来源不明确，V2 评审结论未集中记录。
- docs 目录存在冗余与过期文档，索引重复。

### 后续（2026-02 文档整合）

- **NEXT_PHASE_TASKS** §四：精简为摘要表；完整 SQL/验收标准后并入同文档 §六附录（2026-04，见 §二十）。
- **ENHANCEMENT_ROADMAP** §七：增加「当前下阶段以 V2 评审为准」，§八 指向 NEXT_PHASE_TASKS。
- **MODIFICATION_PLAN**：增加早期方案说明，下阶段指向 NEXT_PHASE_TASKS。
- **PROJECT_REVIEW_REPORT** §6：精简为指向 V2 评审，避免重复清单。（**2026-04**：§6 已重写为与 NEXT_PHASE §三–§四 一致，见 §二十一。）

---

## 十七、暗色模式与主题 token（Surface / 卡片）

**日期**：2026-04  
**优先级**：高（可读性）

### 背景

- 暗色模式下若 `--surface` 未在 `.dark` 中定义，会沿用浅色近白（`0 0% 98%`），与 `text-card-foreground`（浅色字）叠加会导致**白底上的字几乎看不见**（典型：预订页「Booking Information」、价格汇总）。
- 多处 `bg-white` + `text-gray-*` 在暗色下也存在对比度问题。

### 修改内容（摘要）

1. **`app/globals.css`**：在 `.dark` 中增加 `--surface: 222.2 84% 4.9%`（与 `--card` 一致）。
2. **`app/[locale]/(dashboard)/book/[rinkId]/page.tsx`**：预订表单容器使用 `bg-card text-card-foreground border border-border`，不再单独使用 `bg-surface` 承载浅色字。
3. **全站多页**：将卡片/表单上的 `bg-white`、`text-gray-*` 逐步替换为 `bg-card`、`text-foreground` / `text-muted-foreground` / `text-card-foreground`；徽章类增加 `dark:` 变体；导航搜索框等改为 `bg-card`。
4. **文档**：新增 `docs/★★★THEMING.md`；更新 `★★★AGENTS.md`、`docs/★★★README.md`、`README.md`、`docs/★★★RENEW_RINKS.md`（npm 脚本说明）。

### 解决的问题

- 暗色模式下白底区块与浅色文字对比度不足。
- 开发者对 `surface` / `card` 在暗色下的行为有统一说明。

---

## 十八、核心 Markdown 文件名 `★★★` 前缀

**日期**：2026-04  
**优先级**：中（可发现性）

### 修改内容

为便于在资源管理器中排序与查找，下列文档重命名并在标题中标注 **★★★**：

| 原路径 | 新路径 |
|--------|--------|
| `AGENTS.md` | `★★★AGENTS.md` |
| `docs/README.md` | `docs/★★★README.md` |
| `docs/RENEW_RINKS.md` | `docs/★★★RENEW_RINKS.md` |
| `docs/THEMING.md` | `docs/★★★THEMING.md` |

根目录 `README.md` 保留标准文件名（Git 托管首页），仅在首行标题使用 `# ★★★ GoGoHockey`。

### 注意

若 Cursor / 规则中曾写死 `AGENTS.md`，请改为 `★★★AGENTS.md`。

---

---

## 十九、`docs/` 目录清理（合并 SQL、删除过时方案）

**日期**：2026-04  
**优先级**：中（可维护性）

### 删除

| 文件 | 原因 |
|------|------|
| `MODIFICATION_PLAN.md` | 早期（2025-02）方案，已由 [TASKS.md](./TASKS.md)（含 V2 附录）替代；内容要点已分散在 CHANGELOG 历史条目中 |
| `SQL_RINK_IMAGE_COLUMNS.sql` | 并入 `SQL_RINKS_IMAGES.sql` 第一节 |
| `SQL_TOP20_IMAGE_VERIFIED.sql` | 并入 `SQL_RINKS_IMAGES.sql` 第二节 |

### 新增

- **`SQL_RINKS_IMAGES.sql`**：单文件分节（列迁移 + Top20 验证），替代上述两个 SQL 文件。

### 引用更新

- `scripts/mark-top20-image-verified.mjs`、`★★★README.md`、`★★★RENEW_RINKS.md`、`NEXT_PHASE_TASKS.md`、`PROJECT_REVIEW_REPORT.md` 已更新。

---

## 二十、V2 评审独立文档并入 NEXT_PHASE_TASKS

**日期**：2026-04  
**优先级**：低（文档去重）

### 修改内容

1. **删除** `docs/V2_REVIEW_NEXT_PHASE.md`：全文迁入 [NEXT_PHASE_TASKS.md §六 附录](./NEXT_PHASE_TASKS.md#v2-review-appendix)（锚点 `v2-review-appendix`）。
2. **更新** `docs/NEXT_PHASE_TASKS.md`：§一–§五 不变；新增 §六 附录（P0–P2 原文、SQL、验收、评分表）。
3. **更新引用**：`★★★README.md`、`PROJECT_REVIEW_REPORT.md`、`ENHANCEMENT_ROADMAP.md`、§十六「后续」条目、§十九 MODIFICATION_PLAN 说明。

---

## 二十一、任务状态文档全库对齐（2026-04）

**日期**：2026-04-05  
**优先级**：中（避免开发误判待办）

### 背景

部分文档（如 `PROJECT_REVIEW_REPORT` §六、`CHANGELOG` §十二「未完成」、`ENHANCEMENT_ROADMAP` §七）仍保留早期表述，易与 **V2 P0/P1 已完成、P2 收尾** 的真实进度冲突。

### 修改内容（权威约定）

1. **唯一权威**：[TASKS.md](./TASKS.md) **§三（进行中）、§四（下阶段摘要）** 表示当前未完成与优先级；§二、§六 附录为历史与验收依据。
2. **更新**：[PROJECT_REVIEW_REPORT.md](./PROJECT_REVIEW_REPORT.md) — 重写 §六（6.0–6.4），修正技术栈中 Stripe/React Query/messages 表述；§八 去重。  
3. **更新**：[ENHANCEMENT_ROADMAP.md](./ENHANCEMENT_ROADMAP.md) — §1.2 取消政策、§1.3 支付、§5.3 语言、§七 优先级表与 V2 状态一致。  
4. **更新**：[CHANGELOG_IMPROVEMENTS.md](./CHANGELOG_IMPROVEMENTS.md) — §十二「未完成」改为历史快照并指向 NEXT_PHASE。  
5. **更新**：[TASKS.md](./TASKS.md) — 文首增加「任务状态唯一权威」说明；状态日期 2026-04-05。  
6. **更新**：[README.md](../README.md)、[docs/★★★README.md](./★★★README.md)、[★★★AGENTS.md](../★★★AGENTS.md) — 增加指向 NEXT_PHASE 的约定说明。

### 解决的问题

- 审查清单与 CHANGELOG「未完成」误导为「Stripe/Webhook/Hydration 未做」。  
- 路线图优先级表未区分 V2 已完成项与长期项。

**后续（2026-04-06）**：V2 P2 代码与文档收口见 **§二十二**。

---

## 二十二、V2 P2 工程收口（XSS + SEO/JSON-LD）

**日期**：2026-04-06  
**分支**：`feat/v2-p2-xss-jsonld-sanitize`（已合并 `main`）、`feat/v2-p2-seo-booking-clubs-metadata`（已合并 `main`）

### 代码与测试

1. **`lib/utils/json-ld.ts`**：新增 `sanitizeJsonLdStrings`，在 `serializeJsonLd` 内对 JSON-LD 对象内**所有字符串**递归执行 `sanitizePlainText`，再输出 `<script type="application/ld+json">` 安全序列。
2. **比赛 UI**：`app/[locale]/(dashboard)/games/page.tsx`、`games/[id]/page.tsx`、`app/(dashboard)/games/page.tsx`、`components/features/game-card-working.tsx` — 对用户可见字段使用 `sanitizePlainText`。
3. **预订与俱乐部 SEO**：新建 `app/[locale]/(dashboard)/bookings/[id]/layout.tsx`（`generateMetadata`、`robots: noindex`、登录用户可见时输出 `Reservation` JSON-LD）；新建 `app/[locale]/(dashboard)/clubs/layout.tsx`（`generateMetadata`）。
4. **测试**：`__tests__/lib/utils/json-ld.test.ts`；`__tests__/lib/queries/games.test.ts` 旧日期用例改为固定日期，避免本地/UTC 漂移。`npm run test` 现为 **90** 个用例。

### 文档

- 更新 [TASKS.md](./TASKS.md)、[PROJECT_REVIEW_REPORT.md](./PROJECT_REVIEW_REPORT.md)、[ENHANCEMENT_ROADMAP.md](./ENHANCEMENT_ROADMAP.md)、[★★★README.md](./★★★README.md)、[README.md](../README.md)、[★★★AGENTS.md](../★★★AGENTS.md)（测试数量）。

---

*文档生成时间：2025-02 | 更新：2026-04-06*
