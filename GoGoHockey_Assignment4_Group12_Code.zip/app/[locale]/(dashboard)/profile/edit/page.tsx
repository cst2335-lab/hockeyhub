'use client';

import {useEffect, useMemo, useState} from 'react';
import {useTranslations} from 'next-intl';
import {createClient} from '@/lib/supabase/client';
import {usePathname, useRouter} from 'next/navigation';
import {ArrowLeft, Save} from 'lucide-react';

interface Profile {
  id: string;
  full_name: string;
  email?: string;
  age_group?: string;
  skill_level?: string;
  position?: string;
  area?: string;
  years_playing?: number;
  phone?: string;
  jersey_number?: string;
  preferred_shot?: string;
  bio?: string;
}

export default function EditProfilePage() {
  const t = useTranslations('profilePage');
  const tActions = useTranslations('actions');
  const router = useRouter();
  const pathname = usePathname();
  const supabase = createClient();

  // Derive locale from the first path segment: /{locale}/...
  const locale = useMemo(() => (pathname?.split('/')?.[1] || '').trim(), [pathname]);
  const withLocale = (p: string) => `/${locale || ''}${p}`.replace('//', '/');

  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{type: 'success' | 'error'; text: string} | null>(null);

  useEffect(() => {
    loadProfile();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function loadProfile() {
    try {
      const {
        data: {user}
      } = await supabase.auth.getUser();

      if (!user) {
        // Localized redirect to login
        router.push(withLocale('/login'));
        return;
      }

      const {data, error} = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();

      if (error) throw error;

      setProfile(data);
    } catch (error) {
      console.error('Error loading profile:', error);
      setMessage({type: 'error', text: t('loadError')});
    } finally {
      setLoading(false);
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!profile) return;

    setSaving(true);
    setMessage(null);

    try {
      const res = await fetch('/api/profile/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({
          full_name: profile.full_name,
          age_group: profile.age_group,
          skill_level: profile.skill_level,
          position: profile.position,
          area: profile.area,
          years_playing: profile.years_playing,
          phone: profile.phone,
          jersey_number: profile.jersey_number,
          preferred_shot: profile.preferred_shot,
          bio: profile.bio,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        throw new Error(data.error || t('updateError'));
      }

      setMessage({type: 'success', text: t('updateSuccess')});
      // Localized redirect after successful save
      setTimeout(() => {
        router.push(withLocale('/profile'));
      }, 1500);
    } catch (error: any) {
      console.error('Error updating profile:', error);
      setMessage({type: 'error', text: error.message || t('updateError')});
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gogo-primary"></div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-muted-foreground">{t('notFound')}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={() => router.push(withLocale('/profile'))}
            className="flex items-center text-muted-foreground hover:text-foreground mb-4 transition"
          >
            <ArrowLeft className="h-4 w-4 mr-2 shrink-0" />
            {t('backToProfile')}
          </button>
          <h1 className="text-3xl font-bold text-foreground">{t('editProfile')}</h1>
          <p className="mt-2 text-muted-foreground">{t('editSubtitle')}</p>
        </div>

        {/* Message */}
        {message && (
          <div
            className={`mb-6 p-4 rounded-lg border ${
              message.type === 'success'
                ? 'bg-green-50 dark:bg-green-900/20 text-green-800 dark:text-green-300 border-green-200 dark:border-green-800/50'
                : 'bg-red-50 dark:bg-red-900/20 text-red-800 dark:text-red-300 border-red-200 dark:border-red-800/50'
            }`}
          >
            {message.text}
          </div>
        )}

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Basic Information */}
          <div className="bg-card border border-border shadow rounded-xl p-6">
            <h2 className="text-lg font-semibold text-foreground mb-4">{t('basicInfo')}</h2>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-foreground">{t('fullName')} *</label>
                <input
                  type="text"
                  required
                  className="mt-1 block w-full border border-input bg-background text-foreground rounded-lg shadow-sm focus:ring-2 focus:ring-gogo-secondary focus:border-gogo-secondary sm:text-sm"
                  value={profile.full_name || ''}
                  onChange={e => setProfile({...profile, full_name: e.target.value})}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground">{t('phoneNumber')}</label>
                <input
                  type="tel"
                  className="mt-1 block w-full border border-input bg-background text-foreground rounded-lg shadow-sm focus:ring-2 focus:ring-gogo-secondary focus:border-gogo-secondary sm:text-sm"
                  placeholder="(613) 555-0100"
                  value={profile.phone || ''}
                  onChange={e => setProfile({...profile, phone: e.target.value})}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground">{t('areaLocation')} *</label>
                <select
                  required
                  className="mt-1 block w-full pl-3 pr-10 py-2 text-base border border-input bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-gogo-secondary focus:border-gogo-secondary sm:text-sm rounded-lg"
                  value={profile.area || ''}
                  onChange={e => setProfile({...profile, area: e.target.value})}
                >
                  <option value="">Select your area</option>
                  <option value="Downtown Ottawa">Downtown Ottawa</option>
                  <option value="Ottawa East">Ottawa East</option>
                  <option value="Ottawa West">Ottawa West</option>
                  <option value="Ottawa South">Ottawa South</option>
                  <option value="Kanata">Kanata</option>
                  <option value="Nepean">Nepean</option>
                  <option value="Orleans">Orleans</option>
                  <option value="Gloucester">Gloucester</option>
                  <option value="Barrhaven">Barrhaven</option>
                  <option value="Stittsville">Stittsville</option>
                </select>
              </div>
            </div>
          </div>

          {/* Hockey Information */}
          <div className="bg-card border border-border shadow rounded-xl p-6">
            <h2 className="text-lg font-semibold text-foreground mb-4">{t('hockeyInfo')}</h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-foreground">{t('ageGroup')} *</label>
                <select
                  required
                  className="mt-1 block w-full pl-3 pr-10 py-2 text-base border border-input bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-gogo-secondary focus:border-gogo-secondary sm:text-sm rounded-lg"
                  value={profile.age_group || ''}
                  onChange={e => setProfile({...profile, age_group: e.target.value})}
                >
                  <option value="">Select age group</option>
                  <option value="U7">U7</option>
                  <option value="U9">U9</option>
                  <option value="U11">U11</option>
                  <option value="U13">U13</option>
                  <option value="U15">U15</option>
                  <option value="U18">U18</option>
                  <option value="Adult">Adult</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground">Skill Level *</label>
                <select
                  required
                  className="mt-1 block w-full pl-3 pr-10 py-2 text-base border border-input bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-gogo-secondary focus:border-gogo-secondary sm:text-sm rounded-lg"
                  value={profile.skill_level || ''}
                  onChange={e => setProfile({...profile, skill_level: e.target.value})}
                >
                  <option value="">Select skill level</option>
                  <option value="AAA">AAA</option>
                  <option value="AA">AA</option>
                  <option value="A">A</option>
                  <option value="B">B</option>
                  <option value="C">C</option>
                  <option value="House League">House League</option>
                  <option value="Beginner">Beginner</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground">{t('position')} *</label>
                <select
                  required
                  className="mt-1 block w-full pl-3 pr-10 py-2 text-base border border-input bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-gogo-secondary focus:border-gogo-secondary sm:text-sm rounded-lg"
                  value={profile.position || ''}
                  onChange={e => setProfile({...profile, position: e.target.value})}
                >
                  <option value="">Select position</option>
                  <option value="Forward">Forward</option>
                  <option value="Defense">Defense</option>
                  <option value="Goalie">Goalie</option>
                  <option value="Any">Any Position</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground">{t('shoots')}</label>
                <select
                  className="mt-1 block w-full pl-3 pr-10 py-2 text-base border border-input bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-gogo-secondary focus:border-gogo-secondary sm:text-sm rounded-lg"
                  value={profile.preferred_shot || ''}
                  onChange={e => setProfile({...profile, preferred_shot: e.target.value})}
                >
                  <option value="">Select</option>
                  <option value="Left">Left</option>
                  <option value="Right">Right</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground">{t('experience')}</label>
                <input
                  type="number"
                  min="0"
                  max="50"
                  className="mt-1 block w-full border border-input bg-background text-foreground rounded-lg shadow-sm focus:ring-2 focus:ring-gogo-secondary focus:border-gogo-secondary sm:text-sm"
                  value={profile.years_playing || 0}
                  onChange={e =>
                    setProfile({...profile, years_playing: parseInt(e.target.value) || 0})
                  }
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground">Jersey Number</label>
                <input
                  type="text"
                  maxLength={3}
                  className="mt-1 block w-full border border-input bg-background text-foreground rounded-lg shadow-sm focus:ring-2 focus:ring-gogo-secondary focus:border-gogo-secondary sm:text-sm"
                  placeholder="99"
                  value={profile.jersey_number || ''}
                  onChange={e => setProfile({...profile, jersey_number: e.target.value})}
                />
              </div>
            </div>
          </div>

            {/* Bio */}
          <div className="bg-card border border-border shadow rounded-xl p-6">
            <h2 className="text-lg font-semibold text-foreground mb-4">{t('aboutYou')}</h2>
            <textarea
              rows={4}
              className="mt-1 block w-full border border-input bg-background text-foreground rounded-lg shadow-sm focus:ring-2 focus:ring-gogo-secondary focus:border-gogo-secondary sm:text-sm"
              placeholder="Tell us about your hockey experience, favorite teams, or anything else..."
              value={profile.bio || ''}
              onChange={e => setProfile({...profile, bio: e.target.value})}
            />
          </div>

          {/* Submit Buttons */}
          <div className="flex justify-end space-x-4">
            <button
              type="button"
              onClick={() => router.push(withLocale('/profile'))}
              className="px-4 py-2 border border-input rounded-lg shadow-sm text-sm font-medium text-foreground bg-background hover:bg-muted focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gogo-secondary transition"
            >
              {tActions('cancel')}
            </button>
            <button
              type="submit"
              disabled={saving}
              className="flex items-center px-4 py-2 border border-transparent rounded-lg shadow-sm text-sm font-medium text-white bg-gogo-primary hover:bg-gogo-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gogo-secondary disabled:opacity-50 disabled:cursor-not-allowed transition"
            >
              <Save className="h-4 w-4 mr-2 shrink-0" />
              {saving ? t('saving') : t('saveChanges')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
