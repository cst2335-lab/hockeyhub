'use client';

import { useEffect, useState, useMemo, useCallback } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { createClient } from '@/lib/supabase/client';
import Link from 'next/link';
import { useRouter, usePathname } from 'next/navigation';
import { toast } from 'sonner';
import { useAuth } from '@/lib/hooks/useAuth';
import { useTranslations } from 'next-intl';
import { fetchMyGamesWithLiveMetrics } from '@/lib/games/fetch-my-games';
import {
  getGameDisplayStatus,
  getGameDisplayStatusLabel,
  isGameActivelyOpen,
} from '@/lib/games/display-status';
import { parseLocalDateParts } from '@/lib/games/schedule';
import { 
  Calendar, 
  MapPin, 
  Users, 
  Eye, 
  Heart, 
  Edit, 
  X,
  Plus,
  Trophy,
  Clock,
  CheckCircle,
  AlertCircle,
  Edit2
} from 'lucide-react';

interface Game {
  id: string;
  title: string;
  game_date: string;
  game_time: string;
  location: string;
  age_group: string;
  skill_level: string;
  description: string;
  status: string;
  view_count: number;
  interested_count: number;
  created_at: string;
}

interface GameInterest {
  id: string;
  game_id: string;
  user_id: string;
  status: string;
  created_at: string;
  game_invitations: Game;
}

interface Stats {
  total: number;
  open: number;
  matched: number;
  cancelled: number;
  totalViews: number;
  totalInterested: number;
}

export default function MyGamesPage() {
  const t = useTranslations('myGames');
  const tGames = useTranslations('games');
  const { user, loading: authLoading } = useAuth();
  const queryClient = useQueryClient();
  const router = useRouter();
  const pathname = usePathname();
  const supabase = useMemo(() => createClient(), []);

  const locale = useMemo(() => (pathname?.split('/')?.[1] || '').trim(), [pathname]);
  const withLocale = useCallback((p: string) => `/${locale}${p}`.replace(/\/{2,}/g, '/'), [locale]);

  const [filter, setFilter] = useState<'all' | 'open' | 'matched' | 'cancelled'>('all');
  const [activeTab, setActiveTab] = useState<'posted' | 'interested'>('posted');

  const { data, isLoading: loading } = useQuery({
    queryKey: ['my-games', user?.id],
    queryFn: async () => {
      if (!user) {
        return {
          games: [],
          interestedGames: [],
          stats: { total: 0, open: 0, matched: 0, cancelled: 0, totalViews: 0, totalInterested: 0 },
        };
      }
      return fetchMyGamesWithLiveMetrics<Game>({
        supabase,
        userId: user.id,
      });
    },
    enabled: !!user,
    staleTime: 0,
    refetchOnMount: 'always',
    refetchOnWindowFocus: true,
  });

  const games = data?.games ?? [];
  const interestedGames = data?.interestedGames ?? [];
  const stats = data?.stats ?? { total: 0, open: 0, matched: 0, cancelled: 0, totalViews: 0, totalInterested: 0 };

  useEffect(() => {
    if (!authLoading && !user) {
      router.push(withLocale('/login'));
    }
  }, [authLoading, user, router, withLocale]);

  if (!authLoading && !user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gogo-primary" aria-hidden />
      </div>
    );
  }

  async function updateGameStatus(gameId: string, newStatus: string) {
    try {
      const res = await fetch('/api/games/status', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({
          gameId,
          status: newStatus,
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error ?? 'Failed to update game status');

      await queryClient.invalidateQueries({ queryKey: ['my-games', user?.id] });
      
      if (newStatus === 'cancelled') {
        toast.success('Game cancelled successfully');
      } else if (newStatus === 'matched') {
        toast.success('Game marked as matched');
      }
    } catch (error) {
      console.error('Error updating game:', error);
      toast.error('Failed to update game status');
    }
  }

  async function deleteGame(gameId: string) {
    if (!confirm('Are you sure you want to delete this game? This action cannot be undone.')) {
      return;
    }

    try {
      const res = await fetch('/api/games/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({ gameId }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error ?? 'Failed to delete game');

      await queryClient.invalidateQueries({ queryKey: ['my-games', user?.id] });
      toast.success('Game deleted successfully');
    } catch (error) {
      console.error('Error deleting game:', error);
      toast.error('Failed to delete game');
    }
  }

  async function removeInterest(interestId: string) {
    if (!confirm('Remove your interest in this game?')) {
      return;
    }

    try {
      const res = await fetch('/api/games/interest/remove', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'same-origin',
        body: JSON.stringify({ interestId }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error ?? 'Failed to remove interest');

      await queryClient.invalidateQueries({ queryKey: ['my-games', user?.id] });
    } catch (error) {
      console.error('Error removing interest:', error);
      toast.error('Failed to remove interest');
    }
  }

  function formatDate(dateStr: string) {
    if (!dateStr) return 'TBD';
    const parts = parseLocalDateParts(dateStr);
    const date = parts
      ? new Date(parts.year, parts.month - 1, parts.day)
      : new Date(dateStr);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const dayOnly = new Date(date);
    dayOnly.setHours(0, 0, 0, 0);
    const diffDays = Math.round((dayOnly.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

    let relativeTime = '';
    if (diffDays === 0) relativeTime = ' (Today)';
    else if (diffDays === 1) relativeTime = ' (Tomorrow)';
    else if (diffDays === -1) relativeTime = ' (Yesterday)';
    else if (diffDays < -1) relativeTime = ` (${Math.abs(diffDays)} days ago)`;
    else if (diffDays > 1 && diffDays <= 7) relativeTime = ` (in ${diffDays} days)`;

    return (
      date.toLocaleDateString('en-US', {
        weekday: 'short',
        month: 'short',
        day: 'numeric',
      }) + relativeTime
    );
  }

  function getStatusBadge(game: { status?: string; game_date?: string; game_time?: string } | string | undefined) {
    if (!game || typeof game === 'string') {
      const display = getGameDisplayStatus({ status: typeof game === 'string' ? game : 'open' });
      const label = getGameDisplayStatusLabel(display);
      if (display === 'open') {
        return <span className="px-2 py-1 text-xs rounded-full bg-green-100 text-green-800 dark:bg-green-900/40 dark:text-green-300">{tGames('statusOpen')}</span>;
      }
      if (display === 'matched') {
        return <span className="px-2 py-1 text-xs rounded-full bg-gogo-secondary/20 text-gogo-primary">{tGames('statusMatched')}</span>;
      }
      if (display === 'cancelled') {
        return <span className="px-2 py-1 text-xs rounded-full bg-muted text-muted-foreground dark:bg-slate-700 dark:text-slate-300">{tGames('statusCancelled')}</span>;
      }
      return <span className="px-2 py-1 text-xs rounded-full bg-muted-foreground/80 text-white dark:bg-slate-600">{label}</span>;
    }
    const display = getGameDisplayStatus({
      status: game.status,
      gameDate: game.game_date,
      gameTime: game.game_time,
    });
    const label = getGameDisplayStatusLabel(display);
    switch (display) {
      case 'open':
        return <span className="px-2 py-1 text-xs rounded-full bg-green-100 text-green-800 dark:bg-green-900/40 dark:text-green-300">{tGames('statusOpen')}</span>;
      case 'matched':
        return <span className="px-2 py-1 text-xs rounded-full bg-gogo-secondary/20 text-gogo-primary">{tGames('statusMatched')}</span>;
      case 'cancelled':
        return <span className="px-2 py-1 text-xs rounded-full bg-muted text-muted-foreground dark:bg-slate-700 dark:text-slate-300">{tGames('statusCancelled')}</span>;
      case 'past':
      case 'closed':
        return <span className="px-2 py-1 text-xs rounded-full bg-muted-foreground/80 text-white dark:bg-slate-600">{label}</span>;
      default:
        return <span className="px-2 py-1 text-xs rounded-full bg-muted text-muted-foreground dark:bg-slate-700 dark:text-slate-300">{label}</span>;
    }
  }

  const filteredGames = filter === 'all'
    ? games
    : filter === 'open'
      ? games.filter((g) =>
          isGameActivelyOpen({
            status: g.status,
            gameDate: g.game_date,
            gameTime: g.game_time,
          })
        )
      : games.filter((g) => g.status === filter);

  const isLoading = authLoading || (!!user && loading);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-gogo-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="mb-8 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-foreground">{t('title')}</h1>
            <p className="mt-2 text-muted-foreground">
              {activeTab === 'posted' ? t('subtitlePosted') : t('subtitleInterested')}
            </p>
          </div>
          <Link
            href={withLocale('/games/new')}
            className="flex items-center px-4 py-2 bg-gogo-primary text-white rounded-lg hover:bg-gogo-dark"
          >
            <Plus className="h-5 w-5 mr-2" />
            {t('postNewGame')}
          </Link>
        </div>

        {/* Main Tabs */}
        <div className="mb-6 flex space-x-1 bg-muted p-1 rounded-lg">
          <button
            onClick={() => setActiveTab('posted')}
            className={`flex-1 py-2 px-4 rounded-md transition ${
              activeTab === 'posted'
                ? 'bg-card text-gogo-primary shadow-sm font-medium'
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            {t('myPostedGames')} ({games.length})
          </button>
          <button
            onClick={() => setActiveTab('interested')}
            className={`flex-1 py-2 px-4 rounded-md transition ${
              activeTab === 'interested'
                ? 'bg-card text-gogo-primary shadow-sm font-medium'
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            {t('gamesInterestedIn')} ({interestedGames.length})
          </button>
        </div>

        {activeTab === 'posted' ? (
          <>
            {/* Stats Cards - Only for posted games */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
              <div className="bg-card border border-border rounded-xl shadow-sm p-4">
                <div className="text-2xl font-bold text-foreground">{stats.total}</div>
                <div className="text-sm text-muted-foreground">{t('totalGames')}</div>
              </div>
              <div className="bg-card border border-border rounded-xl shadow-sm p-4">
                <div className="text-2xl font-bold text-green-600 dark:text-green-400">{stats.open}</div>
                <div className="text-sm text-muted-foreground">{t('open')}</div>
              </div>
              <div className="bg-card border border-border rounded-xl shadow-sm p-4">
                <div className="text-2xl font-bold text-gogo-primary">{stats.matched}</div>
                <div className="text-sm text-muted-foreground">{t('matched')}</div>
              </div>
              <div className="bg-card border border-border rounded-xl shadow-sm p-4">
                <div className="text-2xl font-bold text-muted-foreground">{stats.cancelled}</div>
                <div className="text-sm text-muted-foreground">{t('cancelled')}</div>
              </div>
              <div className="bg-card border border-border rounded-xl shadow-sm p-4">
                <div className="text-2xl font-bold text-purple-600 dark:text-purple-400">{stats.totalViews}</div>
                <div className="text-sm text-muted-foreground">{t('totalViews')}</div>
              </div>
              <div className="bg-card border border-border rounded-xl shadow-sm p-4">
                <div className="text-2xl font-bold text-red-600 dark:text-red-400">{stats.totalInterested}</div>
                <div className="text-sm text-muted-foreground">{t('totalInterested')}</div>
              </div>
            </div>

            {/* Filter Tabs - Only for posted games */}
            <div className="mb-6 flex space-x-4 border-b border-border">
              <button
                onClick={() => setFilter('all')}
                className={`pb-2 px-1 border-b-2 transition ${
                  filter === 'all' 
                    ? 'border-gogo-primary text-gogo-primary font-medium' 
                    : 'border-transparent text-muted-foreground hover:text-foreground'
                }`}
              >
                {t('all')} ({games.length})
              </button>
              <button
                onClick={() => setFilter('open')}
                className={`pb-2 px-1 border-b-2 transition ${
                  filter === 'open' 
                    ? 'border-gogo-primary text-gogo-primary font-medium' 
                    : 'border-transparent text-muted-foreground hover:text-foreground'
                }`}
              >
                {t('open')} ({stats.open})
              </button>
              <button
                onClick={() => setFilter('matched')}
                className={`pb-2 px-1 border-b-2 transition ${
                  filter === 'matched' 
                    ? 'border-gogo-primary text-gogo-primary font-medium' 
                    : 'border-transparent text-muted-foreground hover:text-foreground'
                }`}
              >
                {t('matched')} ({stats.matched})
              </button>
              <button
                onClick={() => setFilter('cancelled')}
                className={`pb-2 px-1 border-b-2 transition ${
                  filter === 'cancelled' 
                    ? 'border-gogo-primary text-gogo-primary font-medium' 
                    : 'border-transparent text-muted-foreground hover:text-foreground'
                }`}
              >
                {t('cancelled')} ({stats.cancelled})
              </button>
            </div>

            {/* Posted Games List */}
            {filteredGames.length > 0 ? (
              <div className="space-y-4">
                {filteredGames.map((game) => (
                  <div key={game.id} className="bg-card border border-border rounded-xl shadow-sm hover:shadow-md transition-shadow">
                    <div className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <h3 className="text-lg font-semibold text-foreground">
                              {game.title}
                            </h3>
                            {getStatusBadge(game)}
                          </div>

                          <div className="grid md:grid-cols-2 gap-4 text-sm text-muted-foreground">
                            <div className="space-y-1">
                              <div className="flex items-center">
                                <Calendar className="h-4 w-4 mr-2" />
                                {formatDate(game.game_date)} at {game.game_time || 'TBD'}
                              </div>
                              <div className="flex items-center">
                                <MapPin className="h-4 w-4 mr-2" />
                                {game.location || 'Location TBD'}
                              </div>
                              <div className="flex items-center">
                                <Users className="h-4 w-4 mr-2" />
                                {game.age_group} - {game.skill_level}
                              </div>
                            </div>
                            
                            <div className="space-y-1">
                              <div className="flex items-center">
                                <Eye className="h-4 w-4 mr-2" />
                                {game.view_count || 0} views
                              </div>
                              <div className="flex items-center">
                                <Heart className="h-4 w-4 mr-2" />
                                {game.interested_count || 0} interested
                              </div>
                              <div className="flex items-center">
                                <Clock className="h-4 w-4 mr-2" />
                                Created {new Date(game.created_at).toLocaleDateString()}
                              </div>
                            </div>
                          </div>

                          {game.description && (
                            <p className="mt-3 text-sm text-muted-foreground line-clamp-2">
                              {game.description}
                            </p>
                          )}

                          {/* Interest Alert */}
                          {game.interested_count > 0 &&
                            isGameActivelyOpen({
                              status: game.status,
                              gameDate: game.game_date,
                              gameTime: game.game_time,
                            }) && (
                            <div className="mt-3 p-2 bg-gogo-secondary/10 border border-gogo-secondary/30 rounded text-sm">
                              <AlertCircle className="inline h-4 w-4 text-gogo-primary mr-1" />
                              <span className="text-gogo-primary">
                                {game.interested_count} team{game.interested_count > 1 ? 's are' : ' is'} interested! 
                                <Link href={withLocale('/notifications')} className="ml-2 underline font-medium">
                                  View in notifications
                                </Link>
                              </span>
                            </div>
                          )}
                        </div>

                        {/* Actions */}
                        <div className="ml-4 flex flex-col space-y-2">
                          <Link
                            href={withLocale(`/games/${game.id}`)}
                            className="text-gogo-primary hover:text-gogo-dark dark:hover:text-sky-300 text-sm"
                          >
                            {t('viewDetails')}
                          </Link>
                          
                          <Link
                            href={withLocale(`/games/${game.id}/edit`)}
                            className="text-purple-600 hover:text-purple-800 dark:hover:text-purple-400 text-sm"
                          >
                            {t('editGame')}
                          </Link>
                          
                          {isGameActivelyOpen({
                            status: game.status,
                            gameDate: game.game_date,
                            gameTime: game.game_time,
                          }) && (
                            <>
                              <button
                                onClick={() => updateGameStatus(game.id, 'matched')}
                                className="text-green-600 hover:text-green-800 text-sm text-left"
                              >
                                {t('markAsMatched')}
                              </button>
                              <button
                                onClick={() => updateGameStatus(game.id, 'cancelled')}
                                className="text-orange-600 hover:text-orange-800 dark:hover:text-orange-400 text-sm text-left"
                              >
                                {t('cancelGame')}
                              </button>
                            </>
                          )}
                          {game.status === 'open' &&
                            !isGameActivelyOpen({
                              status: game.status,
                              gameDate: game.game_date,
                              gameTime: game.game_time,
                            }) && (
                            <button
                              onClick={() => updateGameStatus(game.id, 'cancelled')}
                              className="text-orange-600 hover:text-orange-800 dark:hover:text-orange-400 text-sm text-left"
                            >
                              {t('cancelGame')}
                            </button>
                          )}
                          
                          {game.status === 'cancelled' && (
                            <button
                              onClick={() => updateGameStatus(game.id, 'open')}
                              className="text-green-600 hover:text-green-800 dark:hover:text-green-400 text-sm text-left"
                            >
                              {t('reopenGame')}
                            </button>
                          )}
                          
                          <button
                            onClick={() => deleteGame(game.id)}
                            className="text-red-600 hover:text-red-800 dark:hover:text-red-400 text-sm text-left"
                          >
                            {t('delete')}
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-card border border-border rounded-xl shadow-sm">
                <Trophy className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium text-foreground mb-2">
                  {filter === 'all' ? t('noPostedYet') : t('noFilteredGames', { filter: t(filter as 'open' | 'matched' | 'cancelled') })}
                </h3>
                <p className="text-muted-foreground mb-6">{t('postFirstGameHint')}</p>
                <Link
                  href={withLocale('/games/new')}
                  className="inline-flex items-center px-4 py-2 bg-gogo-primary text-white rounded-md hover:bg-gogo-dark"
                >
                  <Plus className="h-5 w-5 mr-2" />
                  {t('postFirstGame')}
                </Link>
              </div>
            )}
          </>
        ) : (
          /* Interested Games Tab */
          <div className="space-y-4">
            {interestedGames.length > 0 ? (
              interestedGames.map((interest) => (
                <div key={interest.id} className="bg-card border border-border rounded-xl shadow-sm hover:shadow-md transition-shadow">
                  <div className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <h3 className="text-lg font-semibold text-foreground">
                            {interest.game_invitations?.title}
                          </h3>
                          {interest.game_invitations && getStatusBadge(interest.game_invitations)}
                        </div>

                        <div className="grid md:grid-cols-2 gap-4 text-sm text-muted-foreground">
                          <div className="space-y-1">
                            <div className="flex items-center">
                              <Calendar className="h-4 w-4 mr-2" />
                              {formatDate(interest.game_invitations?.game_date)} at {interest.game_invitations?.game_time || 'TBD'}
                            </div>
                            <div className="flex items-center">
                              <MapPin className="h-4 w-4 mr-2" />
                              {interest.game_invitations?.location || 'Location TBD'}
                            </div>
                            <div className="flex items-center">
                              <Users className="h-4 w-4 mr-2" />
                              {interest.game_invitations?.age_group} - {interest.game_invitations?.skill_level}
                            </div>
                          </div>
                          
                          <div className="space-y-1">
                            <div className="flex items-center">
                              <Heart className="h-4 w-4 mr-2" />
                              Interested since {new Date(interest.created_at).toLocaleDateString()}
                            </div>
                            <div className="flex items-center">
                              <CheckCircle className="h-4 w-4 mr-2" />
                              Status: {interest.status || 'pending'}
                            </div>
                          </div>
                        </div>

                        {interest.game_invitations?.description && (
                          <p className="mt-3 text-sm text-muted-foreground line-clamp-2">
                            {interest.game_invitations.description}
                          </p>
                        )}
                      </div>

                      {/* Actions */}
                      <div className="ml-4 flex flex-col space-y-2">
                        <Link
                          href={withLocale(`/games/${interest.game_invitations?.id}`)}
                          className="text-gogo-primary hover:text-gogo-dark dark:hover:text-sky-300 text-sm"
                        >
                          {t('viewDetails')}
                        </Link>
                        
                        <button
                          onClick={() => removeInterest(interest.id)}
                          className="text-red-600 hover:text-red-800 dark:hover:text-red-400 text-sm text-left"
                        >
                          {t('removeInterest')}
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-12 bg-card border border-border rounded-xl shadow-sm">
                <Heart className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-medium text-foreground mb-2">{t('noInterestedYet')}</h3>
                <p className="text-muted-foreground mb-6">{t('browseGamesHint')}</p>
                <Link
                  href={withLocale('/games')}
                  className="inline-flex items-center px-4 py-2 bg-gogo-primary text-white rounded-md hover:bg-gogo-dark"
                >
                  {t('browseGames')}
                </Link>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}