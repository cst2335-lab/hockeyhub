// app/[locale]/(dashboard)/games/page.tsx
'use client';

import {useCallback, useEffect, useMemo, useRef, useState} from 'react';
import {useQuery} from '@tanstack/react-query';
import {createClient} from '@/lib/supabase/client';
import Link from 'next/link';
import {useParams} from 'next/navigation';
import {useTranslations} from 'next-intl';
import {
  Calendar,
  MapPin,
  Users,
  Trophy,
  Eye,
  Heart,
  Plus,
  AlertCircle,
  Search,
  Filter,
  X,
  BadgeInfo,
} from 'lucide-react';
import { GameCardSkeleton } from '@/components/ui/skeleton';
import { sortGamesByMatch } from '@/lib/matching/score';
import { sanitizePlainText } from '@/lib/utils/sanitize';
import { fetchGamesListQuery } from '@/lib/queries/games';
import {
  getGameDisplayStatus,
  getGameDisplayStatusLabel,
  type GameDisplayStatus,
} from '@/lib/games/display-status';
import { formatGameListDate, isGamePast, parseLocalDateParts } from '@/lib/games/schedule';
import { useClientNow } from '@/lib/hooks/useClientNow';

type GameStatus = 'open' | 'matched' | 'closed' | 'cancelled';

interface Game {
  id: string;
  title: string;
  game_date: string;
  game_time: string;
  age_group: string;
  skill_level: string;
  description: string;
  status: GameStatus;
  location?: string;
  view_count?: number;
  interested_count?: number;
  created_at: string;
  isExpired?: boolean;
  displayStatus?: GameDisplayStatus;
}

type DateFilter = 'all' | 'upcoming' | 'past';
type SortBy = 'date' | 'interest' | 'views' | 'recommended';

const PAGE_SIZE = 20;

function normalizeOpenStatus(status: GameStatus): GameDisplayStatus {
  if (status === 'matched' || status === 'closed' || status === 'cancelled') return status;
  return 'open';
}

export default function GamesPage() {
  const { locale } = useParams<{ locale: string }>();
  const t = useTranslations('games');
  const supabase = useMemo(() => createClient(), []);
  const clientNow = useClientNow();

  // Fetch games with React Query
  const { data: gamesData, isLoading: loading } = useQuery({
    queryKey: ['games'],
    queryFn: () => fetchGamesListQuery(supabase),
    staleTime: 0,
    refetchOnMount: 'always',
  });

  // Recompute past/open with the client clock (after mount) so SSR/hydrate match.
  const games = useMemo(() => {
    return (gamesData ?? []).map((g) => {
      if (!clientNow) {
        return {
          ...g,
          displayStatus: (g.displayStatus ?? normalizeOpenStatus(g.status)) as GameDisplayStatus,
          isExpired: Boolean(g.isExpired),
        };
      }
      const displayStatus = getGameDisplayStatus({
        status: g.status,
        gameDate: g.game_date,
        gameTime: g.game_time,
        now: clientNow,
      });
      const isExpired = isGamePast(g.game_date, g.game_time, clientNow) || displayStatus === 'past';
      return { ...g, displayStatus, isExpired };
    });
  }, [gamesData, clientNow]);

  // User preferences for "Recommended" sort (age_group, skill_level, area)
  const { data: userPrefs } = useQuery({
    queryKey: ['games-user-prefs'],
    queryFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return null;
      const { data } = await supabase
        .from('profiles')
        .select('age_group, skill_level, area')
        .eq('id', user.id)
        .maybeSingle();
      const p = data as { age_group?: string; skill_level?: string; area?: string } | null;
      if (!p?.age_group && !p?.skill_level && !p?.area) return null;
      return { age_group: p?.age_group ?? null, skill_level: p?.skill_level ?? null, location: p?.area ?? null };
    },
  });

  const prevFiltersRef = useRef<string>('');

  // Default All so past games stay visible (Upcoming alone looks like they vanished).
  const [dateFilter, setDateFilter] = useState<DateFilter>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [ageGroupFilter, setAgeGroupFilter] = useState('all');
  const [skillLevelFilter, setSkillLevelFilter] = useState('all');
  const [locationFilter, setLocationFilter] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [sortBy, setSortBy] = useState<SortBy>('date');
  const [currentPage, setCurrentPage] = useState(1);

  // constants
  const ageGroups = ['U7', 'U9', 'U11', 'U13', 'U15', 'U18', 'Adult'];
  const skillLevels = ['Beginner', 'Intermediate', 'Advanced', 'Elite'];

  // status badge 样式统一（include past display status)
  const statusBadge: Record<GameDisplayStatus, string> = {
    open: 'bg-green-100 text-green-800 dark:bg-green-900/40 dark:text-green-300',
    matched: 'bg-gogo-secondary/20 text-gogo-primary',
    closed: 'bg-muted text-muted-foreground dark:bg-slate-700 dark:text-slate-300',
    past: 'bg-muted-foreground/80 dark:bg-slate-600 text-white',
    cancelled: 'bg-red-100 text-red-800 dark:bg-red-900/40 dark:text-red-300',
  };

  // locale-aware link helper
  const withLocale = useCallback(
    (p: string) => `/${locale || ''}${p}`.replace('//', '/'),
    [locale],
  );

  const filterKey = `${dateFilter}-${searchTerm}-${ageGroupFilter}-${skillLevelFilter}-${locationFilter}-${sortBy}`;
  const filteredGames = useMemo(() => {
    let list = [...games];

    if (dateFilter === 'upcoming') list = list.filter((g) => !g.isExpired);
    if (dateFilter === 'past') list = list.filter((g) => g.isExpired);

    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      list = list.filter(
        (g) =>
          g.title?.toLowerCase().includes(q) ||
          g.description?.toLowerCase().includes(q) ||
          g.location?.toLowerCase().includes(q),
      );
    }

    if (ageGroupFilter !== 'all') list = list.filter((g) => g.age_group === ageGroupFilter);
    if (skillLevelFilter !== 'all') list = list.filter((g) => g.skill_level === skillLevelFilter);

    if (locationFilter) {
      const q = locationFilter.toLowerCase();
      list = list.filter((g) => g.location?.toLowerCase().includes(q));
    }

    if (sortBy === 'recommended' && userPrefs) {
      list = sortGamesByMatch(list, userPrefs);
    } else {
      list.sort((a, b) => {
        switch (sortBy) {
          case 'interest':
            return (b.interested_count || 0) - (a.interested_count || 0);
          case 'views':
            return (b.view_count || 0) - (a.view_count || 0);
          case 'date':
          case 'recommended':
          default:
            if (a.isExpired !== b.isExpired) return a.isExpired ? 1 : -1;
            return (a.game_date || '').localeCompare(b.game_date || '');
        }
      });
    }

    return list;
  }, [games, dateFilter, searchTerm, ageGroupFilter, skillLevelFilter, locationFilter, sortBy, userPrefs]);

  useEffect(() => {
    if (prevFiltersRef.current !== filterKey) {
      prevFiltersRef.current = filterKey;
      setCurrentPage(1);
    }
  }, [filterKey]);

  const totalPages = Math.max(1, Math.ceil(filteredGames.length / PAGE_SIZE));
  const paginatedGames = filteredGames.slice(
    (currentPage - 1) * PAGE_SIZE,
    currentPage * PAGE_SIZE,
  );

  const clearFilters = () => {
    setSearchTerm('');
    setAgeGroupFilter('all');
    setSkillLevelFilter('all');
    setLocationFilter('');
    setDateFilter('all');
    setSortBy('date');
  };

  const hasActiveFilters = () =>
    Boolean(
      searchTerm ||
        locationFilter ||
        ageGroupFilter !== 'all' ||
        skillLevelFilter !== 'all' ||
        (sortBy !== 'date' && sortBy !== 'recommended'),
    );

  const formatDate = (dateStr: string) => {
    // Absolute calendar label only until client clock is ready (avoids relative SSR drift).
    if (!clientNow) {
      if (!dateStr) return 'TBD';
      const parts = parseLocalDateParts(dateStr);
      if (!parts) return dateStr;
      return new Date(parts.year, parts.month - 1, parts.day).toLocaleDateString('en-US', {
        weekday: 'short',
        month: 'short',
        day: 'numeric',
      });
    }
    return formatGameListDate(dateStr, clientNow);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background py-8">
        <div className="max-w-7xl mx-auto px-4">
          <div className="mb-8 flex justify-between items-center">
            <div>
              <div className="h-9 w-48 bg-muted animate-pulse rounded" />
              <div className="h-5 w-32 mt-2 bg-muted animate-pulse rounded" />
            </div>
            <div className="h-10 w-28 bg-muted animate-pulse rounded" />
          </div>
          <div className="mb-6 h-14 w-full max-w-md bg-muted animate-pulse rounded-xl" />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array.from({ length: 6 }).map((_, i) => (
              <GameCardSkeleton key={i} />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="mb-8 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-foreground">{t('title')}</h1>
            <p className="mt-2 text-muted-foreground">
              {t('gamesFound', { count: filteredGames.length })}
              {hasActiveFilters() && ` ${t('filtered')}`}
            </p>
          </div>

          <Link
            href={withLocale('/games/new')}
            className="flex items-center px-4 py-2 bg-gogo-primary text-white rounded-lg hover:bg-gogo-dark"
          >
            <Plus className="h-5 w-5 mr-2" />
            Post a Game
          </Link>
        </div>

        {/* Search + Filters */}
        <div className="mb-6 bg-card border border-border dark:border-slate-700 rounded-xl shadow-sm p-4">
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground h-5 w-5" />
              <input
                type="text"
                placeholder={t('searchPlaceholder')}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-3 py-2 w-full border border-input bg-background text-foreground rounded-lg focus:outline-none focus:ring-2 focus:ring-gogo-secondary"
              />
            </div>

            <button
              onClick={() => setShowFilters((v) => !v)}
              className={`px-4 py-2 border rounded-lg transition flex items-center gap-2 ${
                showFilters || hasActiveFilters()
                  ? 'bg-gogo-primary/10 border-gogo-primary text-gogo-primary'
                  : 'border-input bg-background text-foreground hover:bg-muted'
              }`}
            >
              <Filter className="h-4 w-4" />
              Filters
              {hasActiveFilters() && (
                <span className="bg-gogo-primary text-white text-xs px-2 py-0.5 rounded-full">
                  Active
                </span>
              )}
            </button>
          </div>

          {showFilters && (
            <div className="mt-4 pt-4 border-t border-border grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
              <div>
                <label className="block text-sm font-medium text-foreground mb-1">{t('ageGroup')}</label>
                <select
                  value={ageGroupFilter}
                  onChange={(e) => setAgeGroupFilter(e.target.value)}
                  className="w-full px-3 py-2 border border-input bg-background text-foreground rounded-lg focus:ring-2 focus:ring-gogo-secondary"
                >
                  <option value="all">{t('dateFilterAll')}</option>
                  {ageGroups.map((g) => (
                    <option key={g} value={g}>
                      {g}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-1">{t('skillLevel')}</label>
                <select
                  value={skillLevelFilter}
                  onChange={(e) => setSkillLevelFilter(e.target.value)}
                  className="w-full px-3 py-2 border border-input bg-background text-foreground rounded-lg focus:ring-2 focus:ring-gogo-secondary"
                >
                  <option value="all">All Levels</option>
                  {skillLevels.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-1">{t('location')}</label>
                <input
                  type="text"
                  placeholder="e.g., Kanata"
                  value={locationFilter}
                  onChange={(e) => setLocationFilter(e.target.value)}
                  className="w-full px-3 py-2 border border-input bg-background text-foreground rounded-lg focus:ring-2 focus:ring-gogo-secondary"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground mb-1">Sort By</label>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as SortBy)}
                  className="w-full px-3 py-2 border border-input bg-background text-foreground rounded-lg focus:ring-2 focus:ring-gogo-secondary"
                >
                  <option value="date">{t('sortByDate')}</option>
                  <option value="recommended">{t('sortByRecommended')}</option>
                  <option value="interest">{t('sortByInterest')}</option>
                  <option value="views">{t('sortByViews')}</option>
                </select>
              </div>

              <div className="flex items-end">
                <button
                  onClick={clearFilters}
                  className="w-full px-4 py-2 text-muted-foreground hover:text-foreground hover:bg-muted rounded-lg transition flex items-center justify-center gap-2"
                >
                  <X className="h-4 w-4" />
                  {t('clearFilters')}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Date Tabs */}
        <div className="mb-6 flex space-x-4 border-b border-border">
          {([
            ['all', `${t('dateFilterAll')} (${games.length})`],
            ['upcoming', `${t('dateFilterUpcoming')} (${games.filter((g) => !g.isExpired).length})`],
            ['past', `${t('dateFilterPast')} (${games.filter((g) => g.isExpired).length})`],
          ] as const).map(([key, label]) => (
            <button
              key={key}
              onClick={() => setDateFilter(key)}
              className={`pb-2 px-1 border-b-2 transition ${
                dateFilter === key
                  ? 'border-gogo-primary text-gogo-primary font-medium'
                  : 'border-transparent text-muted-foreground hover:text-foreground'
              }`}
            >
              {label}
            </button>
          ))}
        </div>

        {/* Grid */}
        {filteredGames.length > 0 ? (
          <>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {paginatedGames.map((game) => {
              const displayStatus =
                game.displayStatus ??
                getGameDisplayStatus({
                  status: game.status,
                  gameDate: game.game_date,
                  gameTime: game.game_time,
                  now: clientNow ?? undefined,
                });
              const isPastGame = game.isExpired || displayStatus === 'past';

              return (
                <div
                  key={game.id}
                  className={`bg-card text-card-foreground rounded-xl shadow-md border border-border dark:border-slate-700 hover:shadow-lg transition-shadow relative ${
                    isPastGame ? 'opacity-75' : ''
                  }`}
                >
                  <div className="absolute top-4 right-4 z-10 flex gap-2">
                    <span className={`text-xs px-2 py-1 rounded-full inline-flex items-center ${statusBadge[displayStatus]}`}>
                      {displayStatus === 'past' ? (
                        <>
                          <AlertCircle className="h-3 w-3 mr-1" />
                          {getGameDisplayStatusLabel(displayStatus)}
                        </>
                      ) : (
                        getGameDisplayStatusLabel(displayStatus)
                      )}
                    </span>
                  </div>

                  <div className="p-6">
                    <h3 className="text-lg font-semibold text-foreground mb-4 pr-16">
                      {sanitizePlainText(game.title) || 'Untitled Game'}
                    </h3>

                    <div className="space-y-2 text-sm text-muted-foreground">
                      <div className="flex items-center">
                        <Calendar className="h-4 w-4 mr-2" />
                        <span className={isPastGame ? 'line-through' : ''}>
                          {formatDate(game.game_date)}
                        </span>
                        {game.game_time && <span className="ml-1">at {game.game_time}</span>}
                      </div>

                      {game.location && (
                        <div className="flex items-center">
                          <MapPin className="h-4 w-4 mr-2" />
                          <span>{sanitizePlainText(game.location)}</span>
                        </div>
                      )}

                      <div className="flex items-center">
                        <Users className="h-4 w-4 mr-2" />
                        <span>
                          {sanitizePlainText(game.age_group)} - {sanitizePlainText(game.skill_level)}
                        </span>
                      </div>
                    </div>

                    {game.description && (
                      <p className="mt-3 text-sm text-muted-foreground line-clamp-2">
                        {sanitizePlainText(game.description)}
                      </p>
                    )}

                    <div className="mt-4 flex items-center space-x-4 text-xs text-muted-foreground">
                      <span className="flex items-center">
                        <Eye className="h-3 w-3 mr-1" />
                        {game.view_count || 0} views
                      </span>
                      <span className="flex items-center">
                        <Heart className="h-3 w-3 mr-1" />
                        {game.interested_count || 0} interested
                      </span>
                    </div>

                    <Link
                      href={withLocale(`/games/${game.id}`)}
                      className={`mt-4 block text-center px-4 py-2 rounded-md transition ${
                        isPastGame
                          ? 'bg-muted text-muted-foreground hover:bg-muted/80'
                          : 'bg-gogo-primary text-white hover:bg-gogo-dark'
                      }`}
                    >
                      {isPastGame ? 'View Details' : 'View Details'}
                    </Link>
                  </div>
                </div>
              );
            })}
          </div>

          {filteredGames.length > PAGE_SIZE && (
            <div className="mt-8 flex items-center justify-center gap-4">
              <button
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage <= 1}
                className="px-4 py-2 rounded-md border border-input bg-background text-foreground hover:bg-gogo-secondary/10 hover:border-gogo-primary hover:text-gogo-primary disabled:opacity-50 disabled:cursor-not-allowed transition"
              >
                {t('prevPage')}
              </button>
              <span className="text-sm text-muted-foreground">
                {t('pageOf', { current: currentPage, total: totalPages })}
              </span>
              <button
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                disabled={currentPage >= totalPages}
                className="px-4 py-2 rounded-md border border-input bg-background text-foreground hover:bg-gogo-secondary/10 hover:border-gogo-primary hover:text-gogo-primary disabled:opacity-50 disabled:cursor-not-allowed transition"
              >
                {t('nextPage')}
              </button>
            </div>
          )}
          </>
        ) : (
          <div className="text-center py-12 bg-card border border-border rounded-xl shadow-sm">
            <Trophy className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium text-foreground mb-2">{t('noGames')}</h3>
            <p className="text-muted-foreground mb-6">
              {hasActiveFilters()
                ? 'Try adjusting your filters or search terms'
                : 'Be the first to post a game invitation!'}
            </p>
            {hasActiveFilters() ? (
              <button
                onClick={clearFilters}
                className="inline-flex items-center px-4 py-2 border border-input bg-background text-foreground rounded-md hover:bg-muted transition"
              >
                <X className="h-5 w-5 mr-2" />
                Clear Filters
              </button>
            ) : (
              <Link
                href={withLocale('/games/new')}
                className="inline-flex items-center px-4 py-2 bg-gogo-primary text-white rounded-md hover:bg-gogo-dark"
              >
                <Plus className="h-5 w-5 mr-2" />
                Post First Game
              </Link>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
