// app/[locale]/(auth)/register/RegisterClient.tsx
'use client';

import { useState } from 'react';
import { createClient } from '@/lib/supabase/client';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useParams } from 'next/navigation';
import { SlimLayout } from '@/components/layout/slim-layout';
import { Logo } from '@/components/ui/logo';

export default function RegisterClient() {
  const router = useRouter();
  const { locale } = useParams<{ locale: string }>();
  const supabase = createClient();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [step, setStep] = useState(1);
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  
  const [profile, setProfile] = useState({
    age_group: '',
    skill_level: '',
    position: '',
    area: '',
    years_playing: 0,
    phone: '',
    jersey_number: '',
    preferred_shot: ''
  });

  const handleStep1Submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !password || !fullName) {
      setError('Please fill in all required fields');
      return;
    }
    setStep(2);
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email,
        password,
      });

      if (authError) throw authError;

      if (authData.user) {
        const profileRes = await fetch('/api/profile/update', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          credentials: 'same-origin',
          body: JSON.stringify({
            full_name: fullName,
            age_group: profile.age_group,
            skill_level: profile.skill_level,
            position: profile.position,
            area: profile.area,
            years_playing: profile.years_playing,
            phone: profile.phone,
            jersey_number: profile.jersey_number,
            preferred_shot: profile.preferred_shot,
            bio: '',
          }),
        });
        const profileData = await profileRes.json().catch(() => ({}));
        if (!profileRes.ok) {
          throw new Error(profileData.error || 'Failed to complete profile setup');
        }

        router.push(`/${locale}/dashboard`);
      }
    } catch (error: any) {
      setError(error.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <SlimLayout>
      <div className="flex">
        <Link href={`/${locale}`} aria-label="Home">
          <Logo size="md" showText={true} light={false} className="h-10 w-auto" />
        </Link>
      </div>
      <h2 className="mt-20 text-lg font-semibold text-foreground">
        Create your GoGoHockey account
      </h2>
      <p className="mt-2 text-sm text-muted-foreground">
        Step {step} of 2: {step === 1 ? 'Basic Information' : 'Hockey Profile'}
      </p>

        {step === 1 ? (
          <form className="mt-8 space-y-6" onSubmit={handleStep1Submit}>
            <div className="rounded-md shadow-sm -space-y-px">
              <div>
                <label htmlFor="full-name" className="sr-only">Full Name</label>
                <input
                  id="full-name"
                  name="fullName"
                  type="text"
                  required
                  className="appearance-none rounded-none relative block w-full px-3 py-2 border border-input bg-background placeholder-muted-foreground text-foreground rounded-t-md focus:outline-none focus:ring-gogo-secondary focus:border-gogo-primary focus:z-10 sm:text-sm"
                  placeholder="Full Name"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                />
              </div>
              <div>
                <label htmlFor="email-address" className="sr-only">Email address</label>
                <input
                  id="email-address"
                  name="email"
                  type="email"
                  autoComplete="email"
                  required
                  className="appearance-none rounded-none relative block w-full px-3 py-2 border border-input bg-background placeholder-muted-foreground text-foreground focus:outline-none focus:ring-gogo-secondary focus:border-gogo-primary focus:z-10 sm:text-sm"
                  placeholder="Email address"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
              <div>
                <label htmlFor="password" className="sr-only">Password</label>
                <input
                  id="password"
                  name="password"
                  type="password"
                  autoComplete="new-password"
                  required
                  className="appearance-none rounded-none relative block w-full px-3 py-2 border border-input bg-background placeholder-muted-foreground text-foreground rounded-b-md focus:outline-none focus:ring-gogo-secondary focus:border-gogo-primary focus:z-10 sm:text-sm"
                  placeholder="Password (min 6 characters)"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
            </div>

            {error && (
              <div className="text-red-500 text-sm text-center">{error}</div>
            )}

            <button
              type="submit"
              className="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-gogo-primary hover:bg-gogo-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gogo-secondary"
            >
              Continue to Hockey Profile
            </button>
          </form>
        ) : (
          <form className="mt-8 space-y-4" onSubmit={handleRegister}>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-foreground">Age Group *</label>
                <select
                  required
                  className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-input bg-background text-foreground focus:outline-none focus:ring-gogo-secondary focus:border-gogo-primary sm:text-sm rounded-md"
                  value={profile.age_group}
                  onChange={(e) => setProfile({...profile, age_group: e.target.value})}
                >
                  <option value="">Select</option>
                  <option value="U7">U7</option>
                  <option value="U9">U9</option>
                  <option value="U11">U11</option>
                  <option value="U13">U13</option>
                  <option value="U15">U15</option>
                  <option value="U18">U18</option>
                  <option value="Adult">Adult</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground">Skill Level *</label>
                <select
                  required
                  className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-input bg-background text-foreground focus:outline-none focus:ring-gogo-secondary focus:border-gogo-primary sm:text-sm rounded-md"
                  value={profile.skill_level}
                  onChange={(e) => setProfile({...profile, skill_level: e.target.value})}
                >
                  <option value="">Select</option>
                  <option value="AAA">AAA</option>
                  <option value="AA">AA</option>
                  <option value="A">A</option>
                  <option value="B">B</option>
                  <option value="C">C</option>
                  <option value="House League">House League</option>
                  <option value="Beginner">Beginner</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground">Position *</label>
                <select
                  required
                  className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-input bg-background text-foreground focus:outline-none focus:ring-gogo-secondary focus:border-gogo-primary sm:text-sm rounded-md"
                  value={profile.position}
                  onChange={(e) => setProfile({...profile, position: e.target.value})}
                >
                  <option value="">Select</option>
                  <option value="Forward">Forward</option>
                  <option value="Defense">Defense</option>
                  <option value="Goalie">Goalie</option>
                  <option value="Any">Any Position</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground">Shoots</label>
                <select
                  className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-input bg-background text-foreground focus:outline-none focus:ring-gogo-secondary focus:border-gogo-primary sm:text-sm rounded-md"
                  value={profile.preferred_shot}
                  onChange={(e) => setProfile({...profile, preferred_shot: e.target.value})}
                >
                  <option value="">Select</option>
                  <option value="Left">Left</option>
                  <option value="Right">Right</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-foreground">Area/Location *</label>
              <select
                required
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-input bg-background text-foreground focus:outline-none focus:ring-gogo-secondary focus:border-gogo-primary sm:text-sm rounded-md"
                value={profile.area}
                onChange={(e) => setProfile({...profile, area: e.target.value})}
              >
                <option value="">Select your area</option>
                <option value="Downtown Ottawa">Downtown Ottawa</option>
                <option value="Ottawa East">Ottawa East</option>
                <option value="Ottawa West">Ottawa West</option>
                <option value="Ottawa South">Ottawa South</option>
                <option value="Kanata">Kanata</option>
                <option value="Nepean">Nepean</option>
                <option value="Orleans">Orleans</option>
                <option value="Gloucester">Gloucester</option>
                <option value="Barrhaven">Barrhaven</option>
                <option value="Stittsville">Stittsville</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-foreground">Years Playing</label>
                <input
                  type="number"
                  min="0"
                  max="50"
                  className="mt-1 block w-full border-input bg-background text-foreground rounded-md shadow-sm focus:ring-gogo-secondary focus:border-gogo-primary sm:text-sm"
                  value={profile.years_playing}
                  onChange={(e) => setProfile({...profile, years_playing: parseInt(e.target.value) || 0})}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-foreground">Jersey #</label>
                <input
                  type="text"
                  maxLength={3}
                  className="mt-1 block w-full border-input bg-background text-foreground rounded-md shadow-sm focus:ring-gogo-secondary focus:border-gogo-primary sm:text-sm"
                  value={profile.jersey_number}
                  onChange={(e) => setProfile({...profile, jersey_number: e.target.value})}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-foreground">Phone Number</label>
              <input
                type="tel"
                className="mt-1 block w-full border-input bg-background text-foreground rounded-md shadow-sm focus:ring-gogo-secondary focus:border-gogo-primary sm:text-sm"
                placeholder="(613) 555-0100"
                value={profile.phone}
                onChange={(e) => setProfile({...profile, phone: e.target.value})}
              />
            </div>

            {error && (
              <div className="text-red-500 text-sm text-center">{error}</div>
            )}

            <div className="flex space-x-4">
              <button
                type="button"
                onClick={() => setStep(1)}
                className="flex-1 py-2 px-4 border border-input bg-background text-foreground rounded-md shadow-sm text-sm font-medium hover:bg-muted focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gogo-secondary"
              >
                Back
              </button>
              <button
                type="submit"
                disabled={isLoading}
                className="flex-1 py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-gogo-primary hover:bg-gogo-dark focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gogo-secondary disabled:opacity-50"
              >
                {isLoading ? 'Creating...' : 'Complete Registration'}
              </button>
            </div>
          </form>
        )}

      <div className="mt-10 text-sm text-foreground">
        Already have an account?{' '}
        <Link href={`/${locale}/login`} className="font-medium text-gogo-primary hover:text-gogo-dark">
          Sign in
        </Link>
      </div>
    </SlimLayout>
  );
}